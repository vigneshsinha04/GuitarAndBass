﻿using GuitarAndBass.Model;
using System;

namespace GuitarAndBass
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Guitar! Please choose a string and optional fret to play a note on Guitar. Ex: 2,1 (No Whitespace)");

            var guitarInput = Console.ReadLine();

            Console.WriteLine("Bass! Please choose a string and optional fret to play a note on Bass. Ex: 2,1 (No Whitespace)");

            var bassInput = Console.ReadLine();

            var guitar = new Guitar((int)Char.GetNumericValue(guitarInput[0]), (int)Char.GetNumericValue(guitarInput[2]));
            var bass = new Bass((int)Char.GetNumericValue(bassInput[0]), (int)Char.GetNumericValue(bassInput[2]));

            var guitarNote = guitar.Play();
            var bassNote = bass.Play();

            if (guitarNote == bassNote && guitarNote != string.Empty && bassNote != string.Empty)
            {
                Console.WriteLine("You have played the same note on Guitar and Bass.");
            }
            else if (guitarNote != bassNote)
            {
                Console.WriteLine("You have played the different notes on Guitar and Bass.");
            }
        }
    }
}
