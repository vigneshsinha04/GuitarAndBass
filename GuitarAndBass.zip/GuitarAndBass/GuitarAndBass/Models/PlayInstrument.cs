﻿namespace GuitarAndBass.Model
{
    public abstract class PlayInstrument
    {
        public int stringCount { get; set; }
        public int fretCount { get; set; }
        public int? stringPosition { get; set; }
        public int? fretPosition { get; set; }

        public void Note(int? stringPosition, int? fretPosition)
        {
            this.stringPosition = stringPosition;
            this.fretPosition = fretPosition;
        }

        public abstract string Play();
        public abstract string Stop();
    }
}
