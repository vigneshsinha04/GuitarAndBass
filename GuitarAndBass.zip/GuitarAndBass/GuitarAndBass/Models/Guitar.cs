﻿using System;

namespace GuitarAndBass.Model
{
    public class Guitar : PlayInstrument
    {
        private string[] noFretNotes = { "E", "A", "D", "G", "B", "E" };
        private string[] firstFretNotes = { "F", "Bb", "Eb", "Ab", "C", "F" };

        public Guitar()
        {
            this.stringCount = 6;
            this.fretCount = 2;
        }

        public Guitar(int stringPosition, int fretPosition)
        {
            this.stringCount = 6;
            this.fretCount = 2;
            this.stringPosition = stringPosition;
            this.fretPosition = fretPosition;
        }

        public override string Play()
        {
            string note = "";

            if (stringPosition != null)
            {
                if (stringPosition < 0 || stringPosition > 5)
                {
                    Console.WriteLine("There was an issue with your string placement on the Guitar. Please lift and select a string from 0 to 5.");
                }
                else
                {
                    if (fretPosition == 0 || fretPosition == null)
                    {
                        note = noFretNotes[(int)stringPosition];
                    }
                    else if (fretPosition == 1)
                    {
                        note = firstFretNotes[(int)stringPosition];
                    }
                    else
                    {
                        Console.WriteLine("There was an issue with your fret placement on the Guitar. Please select a fret of 0 or 1.");
                    }
                }
            }
            return note;
        }
        public override string Stop()
        {
            stringPosition = null;
            fretPosition = null;
            string message = "You have released your notes on the guitar.";

            return message;
        }
    }
}
