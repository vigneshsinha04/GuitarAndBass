﻿using System;

namespace GuitarAndBass.Model
{
    public class Bass : PlayInstrument
    {
        private string[] noFretNotes = { "E", "A", "D", "G" };
        private string[] firstFretNotes = { "F", "A#", "D#", "G#" };
        private string[] secondFretNotes = { "F#", "B", "E", "A" };

        public Bass()
        {
            this.stringCount = 4;
            this.fretCount = 3;
        }

        public Bass(int stringPosition, int fretPosition)
        {
            this.stringCount = 4;
            this.fretCount = 3;
            this.stringPosition = stringPosition;
            this.fretPosition = fretPosition;
        }

        public override string Play()
        {
            string note = "";

            if (stringPosition != null)
            {
                if (stringPosition < 0 || stringPosition > 3)
                {
                    Console.WriteLine("There was an issue with your string placement on the Bass. Please lift and select a string from 0 to 3.");
                }
                else
                {
                    if (fretPosition == 0 || fretPosition == null)
                    {
                        note = noFretNotes[(int)stringPosition];
                    }
                    else if (fretPosition == 1)
                    {
                        note = firstFretNotes[(int)stringPosition];
                    }
                    else if (fretPosition == 2)
                    {
                        note = secondFretNotes[(int)stringPosition];
                    }
                    else
                    {
                        Console.WriteLine("There was an issue with your fret placement on the Bass. Please select a fret of 0, 1, or 2.");
                    }
                }
            }
            return note;
        }
        public override string Stop()
        {
            stringPosition = null;
            fretPosition = null;
            string message = "You have released your notes on the bass.";

            return message;
        }
    }
}
